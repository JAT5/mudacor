package com.example.mudacor;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button btnTroca;
    private Button btnSave;
    private LinearLayout cor1;
    private LinearLayout cor2;
    private LinearLayout cor3;
    private LinearLayout cor4;
    private LinearLayout cor5;


    private String layoutCor1;
    private String layoutCor2;
    private String layoutCor3;
    private String layoutCor4;
    private String layoutCor5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTroca = findViewById(R.id.btnChange);
        btnSave = findViewById(R.id.btnSave);
        cor1 = findViewById(R.id.cor1);
        cor2 = findViewById(R.id.cor2);
        cor3 = findViewById(R.id.cor3);
        cor4 = findViewById(R.id.cor4);
        cor5 = findViewById(R.id.cor5);

        MudaCor();
    }





    private void MudaCor(){

        btnTroca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                cor1.setBackgroundColor(geraRandom());
                cor2.setBackgroundColor(geraRandom());
                cor3.setBackgroundColor(geraRandom());
                cor4.setBackgroundColor(geraRandom());
                cor5.setBackgroundColor(geraRandom());

            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }

    public int geraRandom(){

        Random rnd = new Random();
        int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));

        return color;

    }


}
